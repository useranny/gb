public class LearnException {



    public LearnException(String[][] array) throws MyArraySizeException,MyArrayDataException {

        int sum = 0;
        try {
            if ((array[0].length * array.length) == 16) {
                for (int i = 0; i < 4; i++) {
                    for (int j = 0; j < 4; j++) {
                        try {
                            Integer a = Integer.parseInt(array[i][j]);
                            sum = sum + a;
                            }catch (NumberFormatException n){
                                throw new MyArrayDataException("неверное значение в ячейке " + i + " ; " + j);

                        }
                        finally {

                        }

                    }
                }
                System.out.println("Сумма ЧИСЕЛ, которые удалось сложить: " + sum);
            } else{
                throw new MyArraySizeException("неверный размер массива. Нужен 4*4");
            }
        } finally {

        }



    }
}





