public class TestException {
    public static void main(String[] args) throws MyArraySizeException, NumberFormatException {
        //неверный размер
        String[][] Array0 = {{"1","2","3","4"},{"5","6","7","8"},{"9","10","11","12"}};
        //неверный размер
        String[][] Array1 = {{"1","2","3","4"},{"5","6","7","8"},{"9","10","11","12"},{"13","14","15","16"},{"17","18","19","20"}};
        //символ
        String[][] Array2 = {{"1","2","3","4"},{"a","5","6","7"},{"8","9","10","11"},{"12","13","14","15"}};
        //корректный
        String[][] Array3 = {{"1","2","3","4"},{"16","5","6","7"},{"8","9","10","11"},{"12","13","14","15"}};


        try {
            LearnException ExcMethod1 = new LearnException(Array2);//для проверки вставлять массивы по очереди


        }
        catch (MyArraySizeException e){
            System.out.println("Ошибка введенных данных");
            e.printStackTrace();
        }
        catch (NumberFormatException m){
            System.out.println("Ошибка в ячейке");
            m.printStackTrace();
        }

    }
}
